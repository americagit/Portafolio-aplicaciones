package sust.muro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MuroApplication {

	public static void main(String[] args) {
		SpringApplication.run(MuroApplication.class, args);
	}

}
