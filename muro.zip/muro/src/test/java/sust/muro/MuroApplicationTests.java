package sust.muro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MuroApplicationTests {

	@Test
	void contextLoads() {
	}

}
