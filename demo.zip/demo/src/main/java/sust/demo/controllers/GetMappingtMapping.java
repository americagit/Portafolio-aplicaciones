package sust.demo.controllers;

public @interface GetMappingtMapping {

}
