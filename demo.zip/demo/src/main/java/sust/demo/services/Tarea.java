package sust.demo.services;

public interface Tarea {

  void setCompletada(boolean b);

  int getId();

}
